"use client";
import React, { useState, useRef, useCallback } from "react";
import Link from "next/link";

// ── Types ──────────────────────────────────────────────────────
interface ComponentEntry {
  id: string;
  name: string;
  category: string;
  description: string;
  imageUrl: string | null;
  imageName: string | null;
  createdAt: string;
}

const CATEGORIES = [
  "Resistors",
  "Capacitors",
  "Inductors",
  "Transistors",
  "Diodes",
  "ICs & Chips",
  "Sensors",
  "Connectors",
  "Switches",
  "Power",
  "Other",
];

// ── Helpers ────────────────────────────────────────────────────
function genId() {
  return "CMP" + Math.random().toString(36).slice(2, 8).toUpperCase();
}

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1)  return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

export default function ComponentsPage() {
  // ── Form state ───────────────────────────────────────────────
  const [name,        setName]        = useState("");
  const [category,    setCategory]    = useState(CATEGORIES[0]);
  const [description, setDescription] = useState("");
  const [imageFile,   setImageFile]   = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [dragOver,    setDragOver]    = useState(false);
  const [errors,      setErrors]      = useState<Record<string, string>>({});
  const [submitting,  setSubmitting]  = useState(false);
  const [successMsg,  setSuccessMsg]  = useState("");

  // ── List state ───────────────────────────────────────────────
  const [components, setComponents]  = useState<ComponentEntry[]>([]);
  const [search,     setSearch]      = useState("");
  const [catFilter,  setCatFilter]   = useState("All");
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // ── Image handling ───────────────────────────────────────────
  const handleImageFile = useCallback((file: File) => {
    if (!file.type.startsWith("image/")) {
      setErrors(e => ({ ...e, image: "Only image files are accepted." }));
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setErrors(e => ({ ...e, image: "Image must be under 5 MB." }));
      return;
    }
    setErrors(e => { const n = { ...e }; delete n.image; return n; });
    setImageFile(file);
    const reader = new FileReader();
    reader.onload = ev => setImagePreview(ev.target?.result as string);
    reader.readAsDataURL(file);
  }, []);

  const onFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleImageFile(file);
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault(); setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleImageFile(file);
  };

  const removeImage = () => {
    setImageFile(null); setImagePreview(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  // ── Validation ───────────────────────────────────────────────
  const validate = () => {
    const e: Record<string, string> = {};
    if (!name.trim())        e.name        = "Component name is required.";
    if (name.trim().length > 80) e.name    = "Name must be 80 characters or fewer.";
    if (!description.trim()) e.description = "Description is required.";
    if (description.trim().length < 10) e.description = "Description must be at least 10 characters.";
    return e;
  };

  // ── Submit ───────────────────────────────────────────────────
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }

    setSubmitting(true);
    // Simulate async save (replace with real API call)
    await new Promise(r => setTimeout(r, 700));

    const entry: ComponentEntry = {
      id:          genId(),
      name:        name.trim(),
      category,
      description: description.trim(),
      imageUrl:    imagePreview,
      imageName:   imageFile?.name ?? null,
      createdAt:   new Date().toISOString(),
    };

    setComponents(prev => [entry, ...prev]);
    setSuccessMsg(`"${entry.name}" added successfully!`);
    setTimeout(() => setSuccessMsg(""), 3500);

    // Reset form
    setName(""); setCategory(CATEGORIES[0]); setDescription("");
    removeImage(); setErrors({});
    setSubmitting(false);
  };

  // ── Delete ───────────────────────────────────────────────────
  const confirmDelete = () => {
    setComponents(prev => prev.filter(c => c.id !== deleteTarget));
    setDeleteTarget(null);
  };

  // ── Filtered list ────────────────────────────────────────────
  const filtered = components.filter(c => {
    const matchSearch = c.name.toLowerCase().includes(search.toLowerCase()) ||
                        c.description.toLowerCase().includes(search.toLowerCase());
    const matchCat    = catFilter === "All" || c.category === catFilter;
    return matchSearch && matchCat;
  });

  const usedCategories = ["All", ...Array.from(new Set(components.map(c => c.category)))];

  return (
    <div className="min-h-screen bg-[#f4f8fb] font-['Plus_Jakarta_Sans']">

      {/* ── DELETE CONFIRM MODAL ──────────────────────────────── */}
      {deleteTarget && (
        <div className="fixed inset-0 z-[200] bg-black/40 flex items-center justify-center"
          onClick={() => setDeleteTarget(null)}>
          <div className="bg-white rounded-2xl shadow-2xl w-[380px] max-w-[92vw] overflow-hidden"
            onClick={e => e.stopPropagation()}>
            <div className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center text-xl flex-shrink-0">⚠️</div>
                <div>
                  <div className="font-bold text-gray-800">Delete component</div>
                  <div className="text-xs text-gray-500">This action cannot be undone</div>
                </div>
              </div>
              <p className="text-sm text-gray-600 mb-5">
                Are you sure you want to delete{" "}
                <strong className="text-gray-800">
                  {components.find(c => c.id === deleteTarget)?.name}
                </strong>?
              </p>
              <div className="flex gap-2">
                <button onClick={() => setDeleteTarget(null)}
                  className="flex-1 py-2 rounded-xl border border-gray-200 text-sm text-gray-600 hover:bg-gray-50 transition-colors">
                  Cancel
                </button>
                <button onClick={confirmDelete}
                  className="flex-1 py-2 rounded-xl bg-red-500 hover:bg-red-600 text-white text-sm font-semibold transition-colors">
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── SIDEBAR (same as AdminDashboard) ─────────────────── */}
      <aside className="w-64 min-h-screen bg-white border-r border-gray-200 fixed top-0 left-0 z-50 flex flex-col justify-between shadow-sm">
        <div>
          {/* Brand */}
          <div className="p-5 flex items-center gap-3 border-b border-gray-100 bg-[#006aa0] text-white">
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center text-xl">🎓</div>
            <div>
              <div className="text-sm font-bold tracking-tight">Admin Dashboard</div>
              <div className="text-[10px] text-white/70">Admin Space</div>
            </div>
          </div>

          <nav className="py-3">
            {/* Overview */}
            <div className="px-[18px] pt-3 pb-1.5 text-[10px] font-bold tracking-widest text-gray-400 uppercase">Overview</div>
            <Link href="/admin/dashboard"
              className="w-full flex items-center gap-[9px] px-[18px] py-[10px] text-xs font-semibold border-l-4 border-transparent text-gray-600 hover:bg-gray-50 hover:text-gray-900 transition-all">
              <span className="text-base w-5 text-center">⊞</span> Dashboard
            </Link>
            <Link href="/admin/analytics"
              className="w-full flex items-center gap-[9px] px-[18px] py-[10px] text-xs font-semibold border-l-4 border-transparent text-gray-600 hover:bg-gray-50 hover:text-gray-900 transition-all">
              <span className="text-base w-5 text-center">📈</span> Analytics
            </Link>

            {/* Circuit — Components is active */}
            <div className="px-[18px] pt-4 pb-1.5 text-[10px] font-bold tracking-widest text-gray-400 uppercase">Circuit</div>
            <Link href="/admin_dash/circuit"
              className="w-full flex items-center gap-[9px] px-[18px] py-[10px] text-xs font-semibold border-l-4 border-[#006aa0] bg-blue-50 text-[#006aa0] transition-all">
              <span className="text-base w-5 text-center">🔧</span>
              <span className="flex-1">Components</span>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-[#006aa0] text-white">
                {components.length}
              </span>
            </Link>
            <Link href="/admin/3d-models"
              className="w-full flex items-center gap-[9px] px-[18px] py-[10px] text-xs font-semibold border-l-4 border-transparent text-gray-600 hover:bg-gray-50 hover:text-gray-900 transition-all">
              <span className="text-base w-5 text-center">📦</span>
              <span className="flex-1">3D Models</span>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-gray-100 text-gray-500">Library</span>
            </Link>

            {/* System */}
            <div className="px-[18px] pt-4 pb-1.5 text-[10px] font-bold tracking-widest text-gray-400 uppercase">System</div>
            <Link href="/admin/settings"
              className="w-full flex items-center gap-[9px] px-[18px] py-[10px] text-xs font-semibold border-l-4 border-transparent text-gray-600 hover:bg-gray-50 hover:text-gray-900 transition-all">
              <span className="text-base w-5 text-center">⚙️</span> Settings
            </Link>
          </nav>
        </div>

        <div className="p-[18px] border-t border-gray-100 flex items-center gap-[10px] bg-gray-50">
          <div className="w-[34px] h-[34px] rounded-full bg-[#006aa0] flex items-center justify-center font-bold text-xs text-white">A</div>
          <div>
            <div className="text-xs font-bold text-gray-800">Admin User</div>
            <div className="text-[10px] text-gray-400">Super Admin</div>
          </div>
        </div>
      </aside>

      {/* ── HEADER ───────────────────────────────────────────── */}
      <header className="h-[62px] bg-white/95 backdrop-blur-md border-b border-gray-200 fixed top-0 left-64 right-0 z-40 flex items-center justify-between px-7 shadow-sm">
        <div className="flex items-center gap-2 text-xs text-gray-500">
          <Link href="/app/dashboard" className="hover:text-[#006aa0] transition-colors">Dashboard</Link>
          <span className="text-gray-300">/</span>
          <span className="font-bold text-[#006aa0]">Circuit Components</span>
        </div>
        <div className="flex items-center gap-4">
          <div className="w-9 h-9 rounded-full bg-gray-50 border border-gray-200 flex items-center justify-center text-xs text-gray-600 cursor-pointer relative hover:bg-gray-100 transition-colors">
            🔔<span className="absolute top-[2px] right-[2px] w-[8px] h-[8px] bg-red-500 rounded-full border border-white" />
          </div>
          <div className="w-9 h-9 rounded-full bg-[#006aa0] flex items-center justify-center text-xs font-bold text-white shadow-sm">A</div>
        </div>
      </header>

      {/* ── MAIN ─────────────────────────────────────────────── */}
      <div className="pl-64 pt-[62px]">
        <main className="p-7 flex flex-col gap-7 max-w-[1200px]">

          {/* Page title */}
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-gray-800">Circuit Components</h1>
            <p className="text-sm text-gray-500 mt-1">Add new components to the circuit editor library</p>
          </div>

          {/* Success toast */}
          {successMsg && (
            <div className="flex items-center gap-3 px-5 py-3.5 bg-green-50 border border-green-200 rounded-xl text-sm font-semibold text-green-700">
              <span className="text-base">✅</span> {successMsg}
            </div>
          )}

          <div className="grid grid-cols-1 xl:grid-cols-[1fr_420px] gap-7">

            {/* ── ADD COMPONENT FORM ──────────────────────────── */}
            <div className="bg-white border border-gray-200 rounded-2xl shadow-sm overflow-hidden">
              <div className="bg-[#006aa0] px-6 py-4">
                <h2 className="text-sm font-bold text-white">Add New Component</h2>
                <p className="text-[11px] text-white/70 mt-0.5">Fill in the details and upload a component image</p>
              </div>

              <form onSubmit={handleSubmit} className="p-6 space-y-5">

                {/* Name */}
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-gray-500 mb-1.5">
                    Component Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={e => { setName(e.target.value); setErrors(v => { const n={...v}; delete n.name; return n; }); }}
                    placeholder="e.g. 10kΩ Resistor, NPN Transistor, HC-SR04 Sensor…"
                    maxLength={80}
                    className={`w-full px-3.5 py-2.5 text-sm border rounded-xl outline-none transition-colors
                      ${errors.name ? "border-red-400 bg-red-50" : "border-gray-200 focus:border-[#006aa0]"}`}
                  />
                  <div className="flex justify-between mt-1.5">
                    {errors.name
                      ? <p className="text-xs text-red-500">⚠️ {errors.name}</p>
                      : <span />}
                    <span className="text-[10px] text-gray-400 ml-auto">{name.length}/80</span>
                  </div>
                </div>

                {/* Category */}
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-gray-500 mb-1.5">
                    Category <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-[#006aa0] bg-white cursor-pointer transition-colors"
                  >
                    {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>

                {/* Description */}
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-gray-500 mb-1.5">
                    Description <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    value={description}
                    onChange={e => { setDescription(e.target.value); setErrors(v => { const n={...v}; delete n.description; return n; }); }}
                    placeholder="Describe the component — specifications, use cases, pin configuration, notes…"
                    rows={4}
                    maxLength={500}
                    className={`w-full px-3.5 py-2.5 text-sm border rounded-xl outline-none transition-colors resize-none
                      ${errors.description ? "border-red-400 bg-red-50" : "border-gray-200 focus:border-[#006aa0]"}`}
                  />
                  <div className="flex justify-between mt-1.5">
                    {errors.description
                      ? <p className="text-xs text-red-500">⚠️ {errors.description}</p>
                      : <span />}
                    <span className="text-[10px] text-gray-400 ml-auto">{description.length}/500</span>
                  </div>
                </div>

                {/* Image upload */}
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-gray-500 mb-1.5">
                    Component Image <span className="text-gray-400 font-normal normal-case">(optional · max 5 MB)</span>
                  </label>

                  {!imagePreview ? (
                    <div
                      onDragOver={e => { e.preventDefault(); setDragOver(true); }}
                      onDragLeave={() => setDragOver(false)}
                      onDrop={onDrop}
                      onClick={() => fileInputRef.current?.click()}
                      className={`relative flex flex-col items-center justify-center gap-3 px-6 py-10 border-2 border-dashed rounded-xl cursor-pointer transition-all
                        ${dragOver
                          ? "border-[#006aa0] bg-blue-50"
                          : errors.image
                          ? "border-red-400 bg-red-50"
                          : "border-gray-200 bg-gray-50 hover:border-[#006aa0] hover:bg-blue-50/40"}`}
                    >
                      <div className="w-12 h-12 rounded-xl bg-white border border-gray-200 flex items-center justify-center text-2xl shadow-sm">
                        🖼️
                      </div>
                      <div className="text-center">
                        <p className="text-sm font-semibold text-gray-700">
                          {dragOver ? "Drop to upload" : "Drag & drop or click to upload"}
                        </p>
                        <p className="text-xs text-gray-400 mt-1">PNG, JPG, GIF, WebP up to 5 MB</p>
                      </div>
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={onFileInput}
                        className="hidden"
                      />
                    </div>
                  ) : (
                    <div className="relative border border-gray-200 rounded-xl overflow-hidden bg-gray-50">
                      <img src={imagePreview} alt="preview"
                        className="w-full h-48 object-contain p-4" />
                      <div className="px-4 py-2.5 border-t border-gray-100 flex items-center justify-between bg-white">
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="text-base">📎</span>
                          <span className="text-xs font-medium text-gray-600 truncate">{imageFile?.name}</span>
                          <span className="text-[10px] text-gray-400 flex-shrink-0">
                            {imageFile ? (imageFile.size / 1024).toFixed(0) + " KB" : ""}
                          </span>
                        </div>
                        <button type="button" onClick={removeImage}
                          className="flex-shrink-0 w-7 h-7 rounded-lg bg-red-50 border border-red-200 flex items-center justify-center text-red-500 hover:bg-red-100 transition-colors text-sm">
                          ✕
                        </button>
                      </div>
                    </div>
                  )}
                  {errors.image && <p className="text-xs text-red-500 mt-1.5">⚠️ {errors.image}</p>}
                </div>

                {/* Actions */}
                <div className="flex items-center gap-3 pt-1">
                  <button
                    type="submit"
                    disabled={submitting}
                    className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#006aa0] hover:bg-[#005a8a] text-white text-sm font-semibold transition-colors disabled:opacity-60"
                  >
                    {submitting ? (
                      <><span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" /> Saving…</>
                    ) : (
                      <><span>＋</span> Add Component</>
                    )}
                  </button>
                  <button type="button"
                    onClick={() => { setName(""); setCategory(CATEGORIES[0]); setDescription(""); removeImage(); setErrors({}); }}
                    className="px-5 py-2.5 rounded-xl border border-gray-200 text-sm text-gray-600 hover:bg-gray-50 transition-colors">
                    Reset
                  </button>
                </div>
              </form>
            </div>

            {/* ── SIDEBAR PREVIEW CARD ─────────────────────────── */}
            <div className="flex flex-col gap-5">

              {/* Live preview */}
              <div className="bg-white border border-gray-200 rounded-2xl shadow-sm overflow-hidden">
                <div className="px-5 py-3.5 border-b border-gray-100 flex items-center gap-2">
                  <span className="text-sm font-bold text-gray-700">Live Preview</span>
                  <span className="text-[10px] text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">Card as it will appear</span>
                </div>
                <div className="p-5">
                  <div className="border border-gray-200 rounded-xl overflow-hidden bg-gray-50">
                    {/* Image area */}
                    <div className="h-36 bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center relative overflow-hidden">
                      {imagePreview
                        ? <img src={imagePreview} alt="preview" className="w-full h-full object-contain p-3" />
                        : <span className="text-4xl opacity-30">🔧</span>
                      }
                      <span className="absolute top-2 right-2 text-[10px] font-semibold px-2 py-0.5 rounded-full bg-[#006aa0] text-white">
                        {category}
                      </span>
                    </div>
                    {/* Body */}
                    <div className="p-4 bg-white">
                      <div className="font-bold text-sm text-gray-800 mb-1 truncate">
                        {name.trim() || <span className="text-gray-400 font-normal">Component name…</span>}
                      </div>
                      <p className="text-xs text-gray-500 line-clamp-2 leading-relaxed">
                        {description.trim() || <span className="text-gray-300">Description will appear here…</span>}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1">Total Added</div>
                  <div className="text-2xl font-bold text-[#006aa0]">{components.length}</div>
                </div>
                <div className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1">Categories</div>
                  <div className="text-2xl font-bold text-purple-600">
                    {new Set(components.map(c => c.category)).size || 0}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* ── COMPONENT LIST ──────────────────────────────────── */}
          {components.length > 0 && (
            <div className="bg-white border border-gray-200 rounded-2xl shadow-sm overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-sm font-bold text-gray-800">Added Components</h2>
                  <p className="text-xs text-gray-400 mt-0.5">{components.length} component{components.length !== 1 ? "s" : ""} in library</p>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  {/* Category filter */}
                  <div className="flex flex-wrap gap-1 bg-gray-100 p-1 rounded-lg">
                    {usedCategories.map(c => (
                      <button key={c} onClick={() => setCatFilter(c)}
                        className={`px-3 py-1 rounded-md text-xs font-semibold transition-all ${
                          catFilter === c ? "bg-white text-gray-800 shadow-sm" : "text-gray-500 hover:text-gray-800"}`}>
                        {c}
                      </button>
                    ))}
                  </div>
                  {/* Search */}
                  <div className="flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-full px-3 py-1.5 focus-within:border-[#006aa0] transition-all">
                    <span className="text-gray-400 text-xs">🔍</span>
                    <input type="text" placeholder="Search components…"
                      value={search} onChange={e => setSearch(e.target.value)}
                      className="bg-transparent outline-none text-xs text-gray-700 placeholder:text-gray-400 w-36" />
                  </div>
                </div>
              </div>

              {filtered.length === 0 ? (
                <div className="p-10 text-center text-sm text-gray-400">No components match your search.</div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-0 divide-x divide-y divide-gray-100">
                  {filtered.map(comp => (
                    <div key={comp.id} className="group flex flex-col hover:bg-gray-50/60 transition-colors">
                      {/* Image */}
                      <div className="h-32 bg-gradient-to-br from-gray-100 to-gray-50 flex items-center justify-center relative overflow-hidden">
                        {comp.imageUrl
                          ? <img src={comp.imageUrl} alt={comp.name} className="w-full h-full object-contain p-3" />
                          : <span className="text-3xl opacity-20">🔧</span>
                        }
                        <span className="absolute top-2 left-2 text-[10px] font-semibold px-2 py-0.5 rounded-full bg-[#006aa0] text-white">
                          {comp.category}
                        </span>
                        {/* Delete button on hover */}
                        <button
                          onClick={() => setDeleteTarget(comp.id)}
                          className="absolute top-2 right-2 w-6 h-6 rounded-lg bg-red-500 text-white text-xs flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-sm hover:bg-red-600"
                          title="Delete component"
                        >✕</button>
                      </div>
                      {/* Body */}
                      <div className="p-4 flex flex-col flex-1">
                        <div className="font-bold text-sm text-gray-800 mb-1 truncate" title={comp.name}>{comp.name}</div>
                        <p className="text-xs text-gray-500 leading-relaxed line-clamp-2 flex-1">{comp.description}</p>
                        <div className="flex items-center justify-between mt-3">
                          <span className="text-[10px] font-mono text-gray-400">{comp.id}</span>
                          <span className="text-[10px] text-gray-400">{timeAgo(comp.createdAt)}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Empty state */}
          {components.length === 0 && (
            <div className="bg-white border border-dashed border-gray-200 rounded-2xl p-12 text-center">
              <div className="text-5xl mb-4 opacity-30">🔧</div>
              <p className="text-sm font-semibold text-gray-500">No components yet</p>
              <p className="text-xs text-gray-400 mt-1">Fill in the form above to add your first component to the library.</p>
            </div>
          )}

        </main>
      </div>
    </div>
  );
}
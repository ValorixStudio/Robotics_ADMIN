"use client";
import React, { useState } from "react";
import Link from "next/link";
type ViewState = "dashboard" | "analytics";

interface UserRecord {
  id: string;
  name: string;
  email: string;
  role: string;
  status: "Active" | "Inactive" | "Pending";
  avatarBg: string;
}

interface CustomRole {
  name: string;
  color: string;
  description: string;
}

const PRESET_COLORS = [
  { label: "Blue",   value: "from-blue-500 to-indigo-500",   badge: "bg-blue-100 text-blue-800"     },
  { label: "Teal",   value: "from-teal-400 to-cyan-500",     badge: "bg-teal-100 text-teal-800"     },
  { label: "Purple", value: "from-purple-400 to-pink-500",   badge: "bg-purple-100 text-purple-800" },
  { label: "Green",  value: "from-emerald-400 to-teal-500",  badge: "bg-green-100 text-green-800"   },
  { label: "Orange", value: "from-orange-400 to-amber-500",  badge: "bg-orange-100 text-orange-800" },
  { label: "Rose",   value: "from-rose-400 to-pink-500",     badge: "bg-rose-100 text-rose-800"     },
  { label: "Violet", value: "from-violet-400 to-purple-500", badge: "bg-violet-100 text-violet-800" },
  { label: "Amber",  value: "from-amber-400 to-yellow-500",  badge: "bg-amber-100 text-amber-800"   },
];

const BUILT_IN_ROLES: CustomRole[] = [
  { name: "Student",     color: "bg-blue-100 text-blue-800",     description: "Enrolled learners"     },
  { name: "Teacher",     color: "bg-teal-100 text-teal-800",     description: "Instructors & faculty" },
  { name: "Super Admin", color: "bg-purple-100 text-purple-800", description: "Full platform access"  },
];

// ── Sidebar nav item type ──────────────────────────────────────
interface NavItem {
  id: string;
  label: string;
  icon: string;
  badge?: string;
  href?: string;   // external link — sidebar will navigate instead of setting view
  view?: ViewState; // internal view switch
}

export default function AdminDashboard() {
  const [currentView, setCurrentView]               = useState<ViewState>("dashboard");
  const [searchTerm, setSearchTerm]                 = useState("");
  const [selectedRoleFilter, setSelectedRoleFilter] = useState<string>("All");

  // Custom roles
  const [customRoles, setCustomRoles]                     = useState<CustomRole[]>([]);
  const [showRoleModal, setShowRoleModal]                 = useState(false);
  const [showDeleteRoleConfirm, setShowDeleteRoleConfirm] = useState<string | null>(null);

  // New role form
  const [newRoleName,  setNewRoleName]  = useState("");
  const [newRoleDesc,  setNewRoleDesc]  = useState("");
  const [newRoleColor, setNewRoleColor] = useState(PRESET_COLORS[0].value);
  const [roleNameError, setRoleNameError] = useState("");

  const allRoles: CustomRole[] = [...BUILT_IN_ROLES, ...customRoles];

  // Users
  const [users, setUsers] = useState<UserRecord[]>([
    { id: "STU12345", name: "Arjun Patel",  email: "arjun@educore.in",  role: "Student",     status: "Active",   avatarBg: "from-blue-500 to-indigo-500"   },
    { id: "TCH98765", name: "Ms. Kapoor",   email: "kapoor@educore.in", role: "Teacher",     status: "Active",   avatarBg: "from-teal-400 to-blue-500"     },
    { id: "STU12346", name: "Priya Sharma", email: "priya@educore.in",  role: "Student",     status: "Active",   avatarBg: "from-purple-400 to-pink-500"   },
    { id: "STU12347", name: "Rohit Kumar",  email: "rohit@educore.in",  role: "Student",     status: "Active",   avatarBg: "from-emerald-400 to-teal-500"  },
    { id: "TCH98766", name: "Dr. Verma",    email: "verma@educore.in",  role: "Teacher",     status: "Pending",  avatarBg: "from-orange-400 to-purple-500" },
    { id: "STU12348", name: "Sneha Rao",    email: "sneha@educore.in",  role: "Student",     status: "Inactive", avatarBg: "from-amber-400 to-red-500"     },
  ]);

  const totalUsers  = users.length;
  const activeUsers = users.filter(u => u.status === "Active").length;

  const handleRoleChange   = (id: string, role: string)  => setUsers(u => u.map(x => x.id === id ? { ...x, role } : x));
  const toggleUserStatus   = (id: string)                 => setUsers(u => u.map(x => x.id === id ? { ...x, status: x.status === "Active" ? "Inactive" : "Active" } : x));

  const filteredUsers = users.filter(u => {
    const s = u.name.toLowerCase().includes(searchTerm.toLowerCase()) || u.id.toLowerCase().includes(searchTerm.toLowerCase());
    const r = selectedRoleFilter === "All" || u.role === selectedRoleFilter;
    return s && r;
  });

  // Role CRUD
  const openRoleModal = () => {
    setNewRoleName(""); setNewRoleDesc(""); setNewRoleColor(PRESET_COLORS[0].value); setRoleNameError("");
    setShowRoleModal(true);
  };
  const handleAddRole = () => {
    const t = newRoleName.trim();
    if (!t) { setRoleNameError("Role name is required."); return; }
    if (allRoles.some(r => r.name.toLowerCase() === t.toLowerCase())) { setRoleNameError("Role already exists."); return; }
    const badge = PRESET_COLORS.find(c => c.value === newRoleColor)?.badge ?? "bg-gray-100 text-gray-800";
    setCustomRoles(p => [...p, { name: t, color: badge, description: newRoleDesc.trim() }]);
    setShowRoleModal(false);
  };
  const handleDeleteRole = (name: string) => {
    setCustomRoles(p => p.filter(r => r.name !== name));
    setUsers(p => p.map(u => u.role === name ? { ...u, role: "Student" } : u));
    setShowDeleteRoleConfirm(null);
  };

  // ── Sidebar nav config ────────────────────────────────────────
  const NAV_SECTIONS: { label: string; items: NavItem[] }[] = [
    {
      label: "Overview",
      items: [
        { id: "dashboard", label: "Dashboard", icon: "⊞", view: "dashboard" },
        { id: "analytics", label: "Analytics",  icon: "📈", view: "analytics" },
      ],
    },
    {
      label: "Components",
      items: [
        { id: "circuits", label: "Circuits",   icon: "🔧", href: "/components/circuits",    badge: "Manage" },
        { id: "3d-models",  label: "3D Models",    icon: "📦", href: "/admin/3d-models",  badge: "Library" },
      ],
    },
    {
      label: "System",
      items: [
        { id: "settings", label: "Settings", icon: "⚙️", href: "/admin/settings" },
      ],
    },
  ];

  const isActive = (item: NavItem) => item.view ? currentView === item.view : false;

  return (
    <div className="min-h-screen bg-[#f4f8fb] text-gray-800 font-['Plus_Jakarta_Sans'] flex antialiased">

      {/* ── ADD ROLE MODAL ─────────────────────────────────────── */}
      {showRoleModal && (
        <div className="fixed inset-0 z-[200] bg-black/40 flex items-center justify-center"
          onClick={() => setShowRoleModal(false)}>
          <div className="bg-white rounded-2xl shadow-2xl w-[440px] max-w-[95vw] overflow-hidden"
            onClick={e => e.stopPropagation()}>
            <div className="bg-[#006aa0] text-white px-6 py-4 flex items-center justify-between">
              <div>
                <div className="font-bold text-base">Create New Role</div>
                <div className="text-xs text-white/70 mt-0.5">Custom roles extend the default permission tiers</div>
              </div>
              <button onClick={() => setShowRoleModal(false)}
                className="w-8 h-8 rounded-lg bg-white/20 hover:bg-white/30 flex items-center justify-center text-lg transition-colors">×</button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-gray-500 mb-1.5">
                  Role Name <span className="text-red-500">*</span>
                </label>
                <input type="text" value={newRoleName}
                  onChange={e => { setNewRoleName(e.target.value); setRoleNameError(""); }}
                  placeholder="e.g. Moderator, TA, Inspector…"
                  className={`w-full px-3 py-2.5 text-sm border rounded-xl outline-none transition-colors
                    ${roleNameError ? "border-red-400 bg-red-50" : "border-gray-200 focus:border-[#006aa0]"}`} />
                {roleNameError && <p className="text-xs text-red-500 mt-1.5">⚠️ {roleNameError}</p>}
              </div>
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-gray-500 mb-1.5">
                  Description <span className="text-gray-400 font-normal normal-case">(optional)</span>
                </label>
                <input type="text" value={newRoleDesc} onChange={e => setNewRoleDesc(e.target.value)}
                  placeholder="What can this role do?"
                  className="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-xl outline-none focus:border-[#006aa0] transition-colors" />
              </div>
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-gray-500 mb-2">Badge Colour</label>
                <div className="grid grid-cols-4 gap-2">
                  {PRESET_COLORS.map(c => (
                    <button key={c.value} onClick={() => setNewRoleColor(c.value)}
                      className={`flex items-center gap-1.5 px-2.5 py-2 rounded-xl border text-xs font-semibold transition-all
                        ${newRoleColor === c.value ? "border-[#006aa0] bg-blue-50 text-[#006aa0]" : "border-gray-200 text-gray-600 hover:border-gray-300"}`}>
                      <span className={`w-3 h-3 rounded-full bg-gradient-to-br ${c.value} flex-shrink-0`} />
                      {c.label}
                    </button>
                  ))}
                </div>
                <div className="mt-3 flex items-center gap-2">
                  <span className="text-xs text-gray-400">Preview:</span>
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold
                    ${PRESET_COLORS.find(c => c.value === newRoleColor)?.badge ?? "bg-gray-100 text-gray-800"}`}>
                    {newRoleName.trim() || "Role Name"}
                  </span>
                </div>
              </div>
            </div>
            <div className="px-6 py-4 border-t border-gray-100 flex justify-end gap-2 bg-gray-50">
              <button onClick={() => setShowRoleModal(false)}
                className="px-4 py-2 rounded-xl border border-gray-200 text-sm text-gray-600 hover:bg-gray-100 transition-colors">Cancel</button>
              <button onClick={handleAddRole}
                className="px-5 py-2 rounded-xl bg-[#006aa0] hover:bg-[#005a8a] text-white text-sm font-semibold transition-colors">Create Role</button>
            </div>
          </div>
        </div>
      )}

      {/* ── DELETE ROLE CONFIRM ────────────────────────────────── */}
      {showDeleteRoleConfirm && (
        <div className="fixed inset-0 z-[200] bg-black/40 flex items-center justify-center"
          onClick={() => setShowDeleteRoleConfirm(null)}>
          <div className="bg-white rounded-2xl shadow-2xl w-[380px] max-w-[92vw] overflow-hidden"
            onClick={e => e.stopPropagation()}>
            <div className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center text-xl">⚠️</div>
                <div>
                  <div className="font-bold text-gray-800">Delete role</div>
                  <div className="text-xs text-gray-500">Users with this role will revert to Student</div>
                </div>
              </div>
              <p className="text-sm text-gray-600 leading-relaxed mb-5">
                Delete <strong className="text-gray-800">{showDeleteRoleConfirm}</strong>?
                {users.filter(u => u.role === showDeleteRoleConfirm).length > 0 && (
                  <span className="text-red-600 font-medium">
                    {" "}{users.filter(u => u.role === showDeleteRoleConfirm).length} user(s) will be affected.
                  </span>
                )}
              </p>
              <div className="flex gap-2">
                <button onClick={() => setShowDeleteRoleConfirm(null)}
                  className="flex-1 py-2 rounded-xl border border-gray-200 text-sm text-gray-600 hover:bg-gray-50 transition-colors">Cancel</button>
                <button onClick={() => handleDeleteRole(showDeleteRoleConfirm)}
                  className="flex-1 py-2 rounded-xl bg-red-500 hover:bg-red-600 text-white text-sm font-semibold transition-colors">Delete Role</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════ SIDEBAR ══════════════════ */}
      <aside className="w-64 min-h-screen bg-white border-r border-gray-200 fixed top-0 left-0 z-50 flex flex-col justify-between shadow-sm">
        <div className="flex flex-col flex-1 overflow-y-auto">

          {/* Brand */}
          <div className="p-5 flex items-center gap-3 border-b border-gray-100 bg-[#006aa0] text-white shrink-0">
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center text-xl shadow-sm">🎓</div>
            <div>
              <div className="text-sm font-bold tracking-tight">Admin Dashboard</div>
              <div className="text-[10px] text-white/70">Admin Space</div>
            </div>
          </div>

          {/* Nav sections */}
          <nav className="flex-1 py-3">
            {NAV_SECTIONS.map(section => (
              <div key={section.label} className="mb-1">
                <div className="px-[18px] pt-3 pb-1.5 text-[10px] font-bold tracking-widest text-gray-400 uppercase">
                  {section.label}
                </div>
                {section.items.map(item => {
                  const active = isActive(item);
                  const inner = (
                    <span className={`w-full flex items-center gap-[9px] px-[18px] py-[10px] text-xs font-semibold border-l-4 transition-all
                      ${active
                        ? "bg-blue-50 text-[#006aa0] border-[#006aa0]"
                        : "text-gray-600 border-transparent hover:bg-gray-50 hover:text-gray-900"}`}>
                      <span className="text-base w-5 text-center flex-shrink-0">{item.icon}</span>
                      <span className="flex-1">{item.label}</span>
                      {item.badge && (
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-gray-100 text-gray-500">
                          {item.badge}
                        </span>
                      )}
                    </span>
                  );

                  return item.href ? (
                    <a key={item.id} href={item.href} className="block">{inner}</a>
                  ) : (
                    <button key={item.id} onClick={() => item.view && setCurrentView(item.view)} className="w-full text-left">
                      {inner}
                    </button>
                  );
                })}
              </div>
            ))}
          </nav>
        </div>

        {/* User footer */}
        <div className="p-[18px] border-t border-gray-100 flex items-center gap-[10px] bg-gray-50 shrink-0">
          <div className="w-[34px] h-[34px] rounded-full bg-[#006aa0] flex items-center justify-center font-bold text-xs text-white">A</div>
          <div>
            <div className="text-xs font-bold text-gray-800">Admin User</div>
            <div className="text-[10px] text-gray-400 font-medium">Super Admin</div>
          </div>
        </div>
      </aside>

      {/* ══════════════════ MAIN WORKSPACE ══════════════════ */}
      <div className="flex-1 pl-64 flex flex-col min-h-screen">

        {/* Header */}
        <header className="h-[62px] bg-white/95 backdrop-blur-md border-b border-gray-200 fixed top-0 left-64 right-0 z-40 flex items-center justify-between px-7 shadow-sm">
          <div className="text-xs font-medium text-gray-500">
            Management / <b className="text-[#006aa0] capitalize font-bold">{currentView}</b>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-full px-[14px] py-[6px] w-60 focus-within:border-[#006aa0] focus-within:bg-white transition-all">
              <span className="text-xs text-gray-400">🔍</span>
              <input type="text" placeholder="Search name or ID…"
                value={searchTerm} onChange={e => setSearchTerm(e.target.value)}
                className="bg-transparent border-none outline-none text-xs text-gray-800 w-full placeholder:text-gray-400" />
            </div>
            <div className="w-9 h-9 rounded-full bg-gray-50 border border-gray-200 flex items-center justify-center text-xs text-gray-600 cursor-pointer relative hover:bg-gray-100 transition-colors">
              🔔<span className="absolute top-[2px] right-[2px] w-[8px] h-[8px] bg-red-500 rounded-full border border-white" />
            </div>
            <div className="w-9 h-9 rounded-full bg-[#006aa0] flex items-center justify-center text-xs font-bold text-white shadow-sm">A</div>
          </div>
        </header>

        <main className="pt-[86px] p-7 flex-1 flex flex-col gap-6">
          <h1 className="text-2xl font-bold tracking-tight text-gray-800">
            {currentView === "dashboard" ? "Dashboard Overview" : "Platform Analytics"}
          </h1>

          {/* ──── DASHBOARD ──── */}
          {currentView === "dashboard" && (
            <>
              {/* Stats */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
                  <div className="text-xs text-gray-400 font-bold uppercase tracking-wider mb-1">Total Users</div>
                  <div className="text-3xl font-bold text-blue-600 tracking-tight">{totalUsers}</div>
                  <p className="text-xs text-gray-500 mt-2">All registered accounts</p>
                </div>
                <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
                  <div className="text-xs text-gray-400 font-bold uppercase tracking-wider mb-1">Active Users</div>
                  <div className="text-3xl font-bold text-green-600 tracking-tight">{activeUsers}</div>
                  <p className="text-xs text-green-600 font-medium mt-2">↑ {Math.round((activeUsers / totalUsers) * 100)}% of total</p>
                </div>
                <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
                  <div className="text-xs text-gray-400 font-bold uppercase tracking-wider mb-1">Total Roles</div>
                  <div className="text-3xl font-bold text-purple-600 tracking-tight">{allRoles.length}</div>
                  <p className="text-xs text-gray-500 mt-2">{customRoles.length} custom · {BUILT_IN_ROLES.length} built-in</p>
                </div>
              </div>

              {/* Role Management card */}
              <div className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
                <div className="border-b border-gray-100 px-6 py-4 flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-gray-800">Role Management</h3>
                    <p className="text-xs text-gray-400 mt-0.5">{allRoles.length} roles · hover a custom role to delete</p>
                  </div>
                  <button onClick={openRoleModal}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#006aa0] hover:bg-[#005a8a] text-white text-xs font-semibold transition-colors">
                    ＋ New Role
                  </button>
                </div>
                <div className="p-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {allRoles.map(role => {
                    const isCustom = customRoles.some(r => r.name === role.name);
                    const count    = users.filter(u => u.role === role.name).length;
                    return (
                      <div key={role.name}
                        className="flex items-center justify-between px-4 py-3 rounded-xl border border-gray-100 bg-gray-50 hover:border-gray-200 group transition-all">
                        <div className="flex items-center gap-3 min-w-0">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold flex-shrink-0 ${role.color}`}>
                            {role.name}
                          </span>
                          <div className="min-w-0">
                            <div className="text-xs text-gray-500 truncate">{role.description || (isCustom ? "Custom role" : "Built-in role")}</div>
                            <div className="text-[10px] text-gray-400 font-mono">{count} user{count !== 1 ? "s" : ""}</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-1 ml-2 flex-shrink-0">
                          {isCustom ? (
                            <button onClick={() => setShowDeleteRoleConfirm(role.name)}
                              className="w-6 h-6 rounded-lg flex items-center justify-center text-red-400 hover:bg-red-50 opacity-0 group-hover:opacity-100 transition-all text-sm">
                              🗑
                            </button>
                          ) : (
                            <span className="text-[10px] text-gray-300 px-1.5 py-0.5 rounded border border-gray-200">built-in</span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                  <button onClick={openRoleModal}
                    className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl border-2 border-dashed border-gray-200 text-xs font-semibold text-gray-400 hover:border-[#006aa0] hover:text-[#006aa0] transition-all">
                    ＋ Create Role
                  </button>
                </div>
              </div>

              {/* Users table */}
              <div className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
                <div className="border-b border-gray-200 p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <h3 className="text-lg font-semibold text-gray-800">Users Access Directory</h3>
                  <div className="flex flex-wrap gap-1 bg-gray-100 p-1 rounded-lg">
                    <button onClick={() => setSelectedRoleFilter("All")}
                      className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
                        selectedRoleFilter === "All" ? "bg-white text-gray-800 shadow-sm" : "text-gray-500 hover:text-gray-800"}`}>
                      All
                    </button>
                    {allRoles.map(r => (
                      <button key={r.name} onClick={() => setSelectedRoleFilter(r.name)}
                        className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
                          selectedRoleFilter === r.name ? "bg-white text-gray-800 shadow-sm" : "text-gray-500 hover:text-gray-800"}`}>
                        {r.name}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="overflow-x-auto w-full">
                  <table className="w-full border-collapse text-left text-sm">
                    <thead>
                      <tr className="bg-gray-50 border-b border-gray-200 text-gray-600 font-semibold">
                        <th className="p-4 text-xs tracking-wider uppercase">User</th>
                        <th className="p-4 text-xs tracking-wider uppercase">Email</th>
                        <th className="p-4 text-xs tracking-wider uppercase">Role</th>
                        <th className="p-4 text-xs tracking-wider uppercase">Status</th>
                        <th className="p-4 text-xs tracking-wider uppercase text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {filteredUsers.length > 0 ? filteredUsers.map(user => (
                        <tr key={user.id} className="hover:bg-gray-50/50 transition-colors">
                          <td className="p-4">
                            <div className="flex items-center gap-3">
                              <div className={`w-[32px] h-[32px] rounded-lg bg-gradient-to-br ${user.avatarBg} flex items-center justify-center font-bold text-xs text-white shadow-sm flex-shrink-0`}>
                                {user.name.charAt(0)}
                              </div>
                              <div>
                                <div className="font-semibold text-gray-800">{user.name}</div>
                                <div className="text-[11px] font-mono text-gray-400">{user.id}</div>
                              </div>
                            </div>
                          </td>
                          <td className="p-4 text-gray-600 font-medium text-xs">{user.email}</td>
                          <td className="p-4">
                            <select value={user.role} onChange={e => handleRoleChange(user.id, e.target.value)}
                              className="bg-white border border-gray-200 text-gray-700 text-xs rounded-lg px-2.5 py-1.5 outline-none focus:border-[#006aa0] cursor-pointer shadow-sm">
                              {allRoles.map(r => <option key={r.name} value={r.name}>{r.name}</option>)}
                            </select>
                          </td>
                          <td className="p-4">
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              user.status === "Active"   ? "bg-green-100 text-green-800"  :
                              user.status === "Inactive" ? "bg-red-100 text-red-800"      :
                                                           "bg-amber-100 text-amber-800"}`}>
                              {user.status}
                            </span>
                          </td>
                          <td className="p-4 text-right">
                            <button onClick={() => toggleUserStatus(user.id)}
                              className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                                user.status === "Active"
                                  ? "bg-red-50 border-red-200 text-red-600 hover:bg-red-100"
                                  : "bg-green-50 border-green-200 text-green-600 hover:bg-green-100"}`}>
                              {user.status === "Active" ? "Suspend" : "Activate"}
                            </button>
                          </td>
                        </tr>
                      )) : (
                        <tr><td colSpan={5} className="p-8 text-center text-sm text-gray-400">No users match the current filter.</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
                <div className="border-t border-gray-100 px-6 py-3 flex justify-between text-xs text-gray-400 font-mono">
                  <span>Showing {filteredUsers.length} of {totalUsers} users</span>
                  <span>{activeUsers} active · {totalUsers - activeUsers} inactive</span>
                </div>
              </div>
            </>
          )}

          {/* ──── ANALYTICS ──── */}
          {currentView === "analytics" && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
                <h3 className="text-sm font-bold text-gray-700 mb-4">Role Distribution</h3>
                <div className="space-y-3">
                  {allRoles.map(role => {
                    const count = users.filter(u => u.role === role.name).length;
                    const pct   = totalUsers ? Math.round((count / totalUsers) * 100) : 0;
                    return (
                      <div key={role.name}>
                        <div className="flex justify-between text-xs font-semibold mb-1">
                          <span className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-semibold ${role.color}`}>{role.name}</span>
                          <b>{count} ({pct}%)</b>
                        </div>
                        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div className="h-full bg-[#006aa0] rounded-full transition-all duration-500" style={{ width: `${pct}%` }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
                <h3 className="text-sm font-bold text-gray-700 mb-4">Weekly User Activity</h3>
                <div className="flex items-end gap-3 h-24 pt-2">
                  {[60, 80, 95, 70, 55, 35, 20].map((val, idx) => (
                    <div key={idx} className="flex flex-col items-center gap-1 flex-1">
                      <div className={`w-full rounded-t-md ${idx === 2 ? "bg-teal-400" : "bg-[#006aa0]"}`} style={{ height: `${val}%` }} />
                      <span className="text-[10px] text-gray-400 font-bold mt-1">{["M","T","W","T","F","S","S"][idx]}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm lg:col-span-2">
                <h3 className="text-sm font-bold text-gray-700 mb-4">All Roles Summary</h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs border-collapse">
                    <thead>
                      <tr className="bg-gray-50 border-b border-gray-200">
                        {["Role","Type","Description","Users"].map(h => (
                          <th key={h} className="p-3 text-left font-bold uppercase tracking-wider text-gray-500">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {allRoles.map(role => {
                        const isCustom = customRoles.some(r => r.name === role.name);
                        const count    = users.filter(u => u.role === role.name).length;
                        return (
                          <tr key={role.name} className="hover:bg-gray-50">
                            <td className="p-3"><span className={`inline-flex px-2.5 py-0.5 rounded-full text-xs font-semibold ${role.color}`}>{role.name}</span></td>
                            <td className="p-3">
                              <span className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${
                                isCustom ? "border-purple-200 text-purple-600 bg-purple-50" : "border-gray-200 text-gray-500 bg-gray-50"}`}>
                                {isCustom ? "Custom" : "Built-in"}
                              </span>
                            </td>
                            <td className="p-3 text-gray-500">{role.description || "—"}</td>
                            <td className="p-3 font-mono font-bold text-gray-700">{count}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}